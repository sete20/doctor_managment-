<?php

namespace App\Traits;

trait LogTrait
{
    public function logs()
    {
//        return $this->morphMany(Log::class, 'logable');
    }
}